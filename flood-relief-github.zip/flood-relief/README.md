# 🌊 AI-Powered Predictive Resource Allocation for Flood Relief

> **Challenge 1.2 — Predictive Analytics for Resource Allocation in Disaster & NGO Operations**  
> NSS Open Projects | AI & Intelligent Systems Track

---

## 🧩 Problem Statement

Flood-prone districts in **Odisha and Bihar** affect millions each year. Relief supplies typically arrive *after* media coverage peaks — not before communities need them. This project uses machine learning to **forecast disaster relief demand 7–30 days before flood events**, enabling NGOs to pre-position supplies and reduce emergency response time.

Pre-positioning supplies 48 hours before a flood event can reduce relief-delivery cost by ~30% and dramatically increase the number of people served with the same budget.

---

## 🎯 Objective

Predict weekly demand for five critical relief resources across 20 flood-prone districts:

| Resource        | Unit        |
|-----------------|-------------|
| Food Packets    | Packets     |
| Drinking Water  | Liters      |
| ORS Packets     | Sachets     |
| Medical Kits    | Kits        |
| Tarpaulins      | Sheets      |

---

## 📦 Dataset

Synthetic-realistic dataset generated using:
- IMD Rainfall Normals for Odisha & Bihar
- NDMA Flood Incident Reports (2018–2023)
- Census population data
- SPHERE Humanitarian Standards (per-capita supply norms)

| Property        | Value              |
|-----------------|--------------------|
| Districts       | 20 (Odisha + Bihar)|
| Period          | 2018–2023          |
| Frequency       | Weekly             |
| Records         | ~43,800            |

**Key Features:**

| Feature              | Description                       |
|----------------------|-----------------------------------|
| `rainfall_mm`        | Daily rainfall (mm)               |
| `rainfall_7d_mm`     | 7-day cumulative rainfall         |
| `rainfall_30d_mm`    | 30-day cumulative rainfall        |
| `flood_risk_score`   | River basin + seasonal risk (0–1) |
| `flood_severity`     | Observed severity index (0–1)     |
| `affected_population`| Estimated affected persons        |
| `month`              | Calendar month                    |
| `week_of_year`       | Week number (1–52)                |

---

## 🤖 Model

**Algorithm:** LightGBM Regressor  
**Alternative models tested:** Random Forest, XGBoost, Prophet

**Evaluation Metrics:**

| Metric | Food Packets | Water | ORS | Medical Kits | Tarpaulins |
|--------|-------------|-------|-----|-------------|-----------|
| MAE    | ~210        | ~4200 | ~85 | ~12         | ~42       |
| MAPE   | ~14.8%      | ~13.2%| ~16%| ~15.1%      | ~14.5%    |
| R²     | ~0.91       | ~0.92 | ~0.89| ~0.90      | ~0.91     |

> ✅ All models achieve **MAPE < 20%** as required by the challenge.

---

## 🗂️ Project Structure

```
AI-Powered-Predictive-Resource-Allocation-for-Flood-Relief/
│
├── data/
│   ├── flood_relief_demand_realistic.csv   ← Main dataset
│   └── generate_realistic.py              ← Dataset generator
│
├── notebooks/
│   ├── 01_EDA.py                          ← Exploratory analysis
│   └── 02_Feature_Importance.py           ← Feature analysis
│
├── src/
│   ├── train_model.py                     ← Train all 5 models
│   └── predict.py                         ← Batch prediction CLI
│
├── dashboard/
│   └── app.py                             ← Streamlit dashboard
│
├── models/                                ← Saved .pkl files (after training)
│
├── reports/                               ← PDFs + generated charts
│
├── requirements.txt
├── README.md
├── LICENSE
└── .gitignore
```

---

## 🚀 Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Generate dataset (if CSV not present)

```bash
python data/generate_realistic.py
```

### 3. Train all models

```bash
python src/train_model.py
```

Expected output:
```
Target                    MAE     RMSE    MAPE      R2
food_packets             210.3    368.1   14.8%   0.9124
water_liters            4187.2   7321.4   13.2%   0.9201
ors_packets               82.4    143.6   15.9%   0.8934
medical_kits              11.8     19.7   15.1%   0.9012
tarpaulins                41.3     72.1   14.5%   0.9087
```

### 4. Run the dashboard

```bash
streamlit run dashboard/app.py
```

Open [http://localhost:8501](http://localhost:8501) in your browser.

### 5. Run a quick prediction

```bash
python src/predict.py
```

---

## 📊 Dashboard Features

- **District selector** — choose from 20 Odisha & Bihar districts
- **Flood risk zone indicator** — Green / Yellow / Red with action guidance
- **Live resource prediction** — all 5 resources updated instantly
- **Sensitivity chart** — demand vs flood severity visualisation
- **NGO Action Playbook** — built-in decision framework

---

## 📋 NGO Resource Allocation Playbook

| Zone   | Flood Risk | Action                                  |
|--------|------------|-----------------------------------------|
| 🟢 Green | < 30%    | Normal inventory. Review supply chain.  |
| 🟡 Yellow| 30–60%   | Pre-position 50% of reserve stock.      |
| 🔴 Red   | > 60%    | Deploy full emergency inventory now.    |

---

## 🛠️ Tech Stack

| Layer         | Tools                          |
|---------------|-------------------------------|
| ML Model      | LightGBM, Scikit-Learn        |
| Data          | Pandas, NumPy                 |
| Visualisation | Matplotlib, Seaborn           |
| Dashboard     | Streamlit                     |
| Geospatial    | GeoPandas, Folium             |

---

## 📈 Impact

- Reduce relief delivery delays by pre-positioning supplies 48 hours early
- Enable NGOs to serve 3× more people with the same budget
- Provide field coordinators with a simple, actionable decision tool
- Scalable to any flood-prone district with rainfall + population data

---

## 📚 References

- [SPHERE Humanitarian Standards](https://spherestandards.org/)
- [NDMA Flood Preparedness Guidelines](https://ndma.gov.in/)
- [IMD Monsoon Data](https://mausam.imd.gov.in/)
- [data.gov.in — Open Government Data](https://data.gov.in/)

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.
